package com.example.streaming.data

import com.example.streaming.model.MediaItem

interface CatalogRepository {
    suspend fun getFeatured(): List<MediaItem>
    suspend fun search(query: String): List<MediaItem>
    suspend fun getById(id: String): MediaItem?
}

/**
 * Fictional local demo data. Replace this implementation with an API you own.
 * No MovieBox endpoint is used by this sample.
 */
class DemoCatalogRepository : CatalogRepository {
    private val items = listOf(
        MediaItem("northstar", "Northstar", "A small research crew follows a mysterious signal beyond the ice.", 2025, "Sci-Fi", "8.1", "🚀", DEMO_STREAM),
        MediaItem("blue-hour", "Blue Hour", "Two friends rebuild a coastal cinema after a storm.", 2024, "Drama", "7.8", "🌊", DEMO_STREAM),
        MediaItem("paper-city", "Paper City", "A young illustrator discovers a hidden map in an old library.", 2025, "Mystery", "8.0", "🏙️", DEMO_STREAM),
        MediaItem("wild-trail", "Wild Trail", "A documentary journey through remote mountain habitats.", 2023, "Documentary", "7.6", "🏔️", DEMO_STREAM),
        MediaItem("last-orbit", "Last Orbit", "A repair pilot races to bring a stranded station back online.", 2024, "Adventure", "7.9", "🪐", DEMO_STREAM),
        MediaItem("tiny-giants", "Tiny Giants", "A family-friendly look at the hidden lives of insects.", 2022, "Family", "8.3", "🦋", DEMO_STREAM)
    )

    override suspend fun getFeatured() = items
    override suspend fun search(query: String): List<MediaItem> =
        if (query.isBlank()) emptyList()
        else items.filter { "${it.title} ${it.genre} ${it.description}".contains(query, ignoreCase = true) }
    override suspend fun getById(id: String) = items.firstOrNull { it.id == id }

    companion object {
        // Public sample stream for development only; replace for production.
        const val DEMO_STREAM =
            "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    }
}
