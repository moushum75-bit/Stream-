package com.example.streaming.model

data class MediaItem(
    val id: String,
    val title: String,
    val description: String,
    val year: Int,
    val genre: String,
    val rating: String,
    val posterEmoji: String,
    val playbackUrl: String? = null
)
