package com.example.streaming.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.streaming.data.DemoCatalogRepository
import com.example.streaming.ui.screens.*

private val repository = DemoCatalogRepository()
private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1A1C24)
private val Accent = Color(0xFFFFC857)

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route.orEmpty()
    val topLevel = route in setOf("home", "search", "downloads", "profile")
    var isPremium by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            if (topLevel) NavigationBar(containerColor = Panel, contentColor = Color.White) {
                val tabs = listOf(
                    Triple("home", "Home", Icons.Default.Home),
                    Triple("search", "Search", Icons.Default.Search),
                    Triple("downloads", "Downloads", Icons.Default.Download),
                    Triple("profile", "Me", Icons.Default.Person),
                    Triple("premium", "Premium", Icons.Default.Star)
                )
                tabs.forEach { (target, label, icon) ->
                    NavigationBarItem(
                        selected = route == target,
                        onClick = {
                            nav.navigate(target) {
                                popUpTo(nav.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Accent,
                            indicatorColor = Color(0xFF30303A),
                            unselectedIconColor = Color.LightGray,
                            unselectedTextColor = Color.LightGray
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen(repository) { nav.navigate("detail/$it") } }
            composable("search") { SearchScreen(repository) { nav.navigate("detail/$it") } }
            composable("downloads") { DownloadsScreen() }
            composable("profile") { ProfileScreen(onPremium = { nav.navigate("premium") }, isPremium = isPremium) }
            composable("premium") { PremiumScreen(isPremium = isPremium, onBack = { nav.popBackStack() }, onDemoActivate = { isPremium = true }, onDemoCancel = { isPremium = false }) }
            composable(
                "detail/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { backStack ->
                DetailScreen(repository, backStack.arguments?.getString("id").orEmpty(),
                    onBack = { nav.popBackStack() },
                    onPlay = { nav.navigate("player/$it") })
            }
            composable(
                "player/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { backStack ->
                PlayerScreenRoute(repository, backStack.arguments?.getString("id").orEmpty(), isPremium = isPremium) {
                    nav.popBackStack()
                }
            }
        }
    }
}
