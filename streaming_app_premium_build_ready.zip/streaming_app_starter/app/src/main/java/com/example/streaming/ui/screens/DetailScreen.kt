package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.streaming.data.CatalogRepository
import com.example.streaming.model.MediaItem

@Composable
fun DetailScreen(
    repository: CatalogRepository,
    id: String,
    onBack: () -> Unit,
    onPlay: (String) -> Unit
) {
    var item by remember(id) { mutableStateOf<MediaItem?>(null) }
    LaunchedEffect(id) { item = repository.getById(id) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        if (item == null) {
            CircularProgressIndicator()
        } else {
            val media = item!!
            Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                Text(media.posterEmoji, style = MaterialTheme.typography.displayLarge)
            }
            Text(media.title, color = Color.White, style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(8.dp))
            Text("${media.year} • ${media.genre} • ★ ${media.rating}", color = Color(0xFFFFC857))
            Spacer(Modifier.height(16.dp))
            Text(media.description, color = Color.LightGray, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(24.dp))
            Button(onClick = { onPlay(media.id) }, enabled = !media.playbackUrl.isNullOrBlank()) {
                Text("▶  Play sample")
            }
            Text("Demo catalogue item. Use content you are authorized to distribute.", color = Color.Gray,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
        }
    }
}
