package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DownloadsScreen() {
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Downloads", "Watch your saved videos offline")
        EmptyMessage("No downloads yet.")
        Text(
            "Production TODO: implement Media3 DownloadService, DownloadManager, persistent download state, storage constraints and a user-visible delete action.",
            modifier = Modifier.padding(18.dp),
            style = MaterialTheme.typography.bodySmall
        )
    }
}
