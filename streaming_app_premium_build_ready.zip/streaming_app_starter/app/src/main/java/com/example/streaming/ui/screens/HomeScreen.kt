package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.streaming.data.CatalogRepository
import com.example.streaming.model.MediaItem
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(repository: CatalogRepository, onSelect: (String) -> Unit) {
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { items = repository.getFeatured() }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            ScreenTitle("Stream", "Discover something worth watching")
            if (items.isNotEmpty()) {
                val featured = items.first()
                Card(
                    onClick = { onSelect(featured.id) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF30313B))
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text("FEATURED", color = Color(0xFFFFC857), style = MaterialTheme.typography.labelLarge)
                        Text(featured.posterEmoji, style = MaterialTheme.typography.displayLarge)
                        Text(featured.title, color = Color.White, style = MaterialTheme.typography.headlineSmall)
                        Text(featured.description, color = Color.LightGray, maxLines = 2)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { onSelect(featured.id) }) { Text("View details") }
                    }
                }
            }
            ScreenTitle("Popular picks")
        }
        items(items, key = { it.id }) { item -> MediaCard(item) { onSelect(item.id) } }
        item { Spacer(Modifier.height(12.dp)) }
    }
}
