package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as PlayerMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.platform.LocalContext
import com.example.streaming.data.CatalogRepository

@Composable
fun PlayerScreenRoute(repository: CatalogRepository, id: String, isPremium: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("Loading player…") }
    var streamUrl by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(id) {
        val media = repository.getById(id)
        title = media?.title ?: "Title not found"
        streamUrl = media?.playbackUrl
    }

    Column(Modifier.fillMaxSize()) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
        if (isPremium) { Text("Premium • Ad-free playback", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), color = androidx.compose.ui.graphics.Color(0xFFFFC857)) }
        if (streamUrl == null) {
            Text("No playable stream configured.", modifier = Modifier.padding(16.dp))
        } else {
            val player = remember(streamUrl) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(PlayerMediaItem.fromUri(streamUrl!!))
                    prepare()
                    playWhenReady = true
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
        }
    }
}
