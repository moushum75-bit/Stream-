package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun PremiumScreen(
    isPremium: Boolean,
    onBack: () -> Unit,
    onDemoActivate: () -> Unit,
    onDemoCancel: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Spacer(Modifier.height(12.dp))
        Text("Stream Premium", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color(0xFFFFC857))
        Text("One subscription. A cleaner viewing experience.", color = Color.LightGray)
        Spacer(Modifier.height(20.dp))
        listOf("No banner or interstitial ads", "No ads during video playback", "Premium badge and account status", "Monthly and yearly plan options").forEach {
            Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF72D6A0))
                Spacer(Modifier.width(10.dp))
                Text(it, color = Color.White)
            }
        }
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF242630))) {
            Column(Modifier.padding(16.dp)) {
                Text("Monthly", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text("Price supplied by Google Play when billing is connected", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = Color.DarkGray)
                Spacer(Modifier.height(12.dp))
                Text("Yearly", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text("Price supplied by Google Play when billing is connected", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(18.dp))
        if (isPremium) {
            Text("Premium active (local demo state)", color = Color(0xFF72D6A0), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onDemoCancel, modifier = Modifier.fillMaxWidth()) { Text("Turn off demo Premium") }
        } else {
            Button(onClick = onDemoActivate, modifier = Modifier.fillMaxWidth()) { Text("Preview Premium (demo only)") }
        }
        Spacer(Modifier.height(12.dp))
        Text("Demo only: this preview button does not charge you or create a real subscription. Before publishing, connect Google Play Billing, configure monthly/yearly product IDs in Play Console, and verify purchase tokens on your backend. Only a verified entitlement should disable ads.", color = Color(0xFFFFD98A), style = MaterialTheme.typography.bodySmall)
    }
}
