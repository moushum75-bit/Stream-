package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ProfileScreen(onPremium: () -> Unit, isPremium: Boolean) {
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Me", "Account and app preferences")
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF25232A))) {
            Column(Modifier.padding(16.dp)) {
                Text(if (isPremium) "Premium is active" else "Upgrade to Premium", style = MaterialTheme.typography.titleLarge, color = Color(0xFFFFC857))
                Spacer(Modifier.height(6.dp))
                Text(if (isPremium) "Ad-free app experience (demo state)." else "Enjoy an ad-free experience across app screens and playback.", color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onPremium) { Text(if (isPremium) "Manage Premium" else "Explore Premium") }
            }
        }
        listOf("Sign in", "Watch history", "Favorites", "Playback settings", "Privacy", "Help & feedback").forEach { label ->
            ListItem(headlineContent = { Text(label) }, supportingContent = { Text("Demo entry — connect to your own feature implementation.") })
            HorizontalDivider()
        }
    }
}
