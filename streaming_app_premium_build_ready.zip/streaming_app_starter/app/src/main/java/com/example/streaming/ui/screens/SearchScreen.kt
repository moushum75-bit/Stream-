package com.example.streaming.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.streaming.data.CatalogRepository
import com.example.streaming.model.MediaItem

@Composable
fun SearchScreen(repository: CatalogRepository, onSelect: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    LaunchedEffect(query) { results = repository.search(query) }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Search", "Find a title or genre")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            label = { Text("Title, genre or keyword") },
            singleLine = true
        )
        if (query.isBlank()) EmptyMessage("Try “sci-fi”, “drama” or a title.")
        else if (results.isEmpty()) EmptyMessage("No matches found.")
        else LazyColumn { items(results, key = { it.id }) { MediaCard(it) { onSelect(it.id) } } }
    }
}
