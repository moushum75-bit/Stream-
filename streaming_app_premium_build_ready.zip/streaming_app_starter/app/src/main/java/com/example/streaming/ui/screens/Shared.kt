package com.example.streaming.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.streaming.model.MediaItem

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
        if (subtitle != null) Text(subtitle, color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun MediaCard(item: MediaItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .background(Color(0xFF1A1C24), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(width = 92.dp, height = 112.dp)
                .background(Color(0xFF30313B), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) { Text(item.posterEmoji, style = MaterialTheme.typography.displayMedium) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("${item.year}  •  ${item.genre}  •  ★ ${item.rating}", color = Color(0xFFFFC857), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(7.dp))
            Text(item.description, color = Color.LightGray, maxLines = 3, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun EmptyMessage(text: String) {
    Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.LightGray)
    }
}
