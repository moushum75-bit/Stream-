package com.example.streaming.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun StreamTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Color(0xFFFFC857),
        onPrimary = Color(0xFF1B1B1B),
        background = Color(0xFF101116),
        surface = Color(0xFF1A1C24),
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}
